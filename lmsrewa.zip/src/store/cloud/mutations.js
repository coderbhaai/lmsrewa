export const SET_ITEMS = (state, items) => {
  state.items = items;
};
