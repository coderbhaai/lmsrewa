<template>
    <q-page padding>
        About
    </q-page>
</template>
<script>
export default {
};
</script>
<style>
</style>
