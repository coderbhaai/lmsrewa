export default {
  items: [],
  allFolders: [],
  path: '/',
  selectedItems: [],
  loading: false,
  viewMode: 'list',
  selectMode: false,
};
